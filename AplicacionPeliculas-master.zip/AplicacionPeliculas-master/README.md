# peliculas

proyecto de flutter para peliculas.

## notas

este projecto esta realizado para practicas con flutter.

para iniciar este projecto es necesario instalar:

NodeJs,
Flutter,
AndroidStudio,
Dart

## Flutter

Si quieres saber más de flutter:

- [Lab: Escribe tu primera App con Flutter](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Muestras útiles de Flutter](https://flutter.dev/docs/cookbook)

para obtener ayuda de como comenzar con Flutter, Consultar:
[documentación online](https://flutter.dev/docs), ofrece tutoriales,
ejemplos, orientación sobre desarrollo móvil y una referencia completa de la API.
