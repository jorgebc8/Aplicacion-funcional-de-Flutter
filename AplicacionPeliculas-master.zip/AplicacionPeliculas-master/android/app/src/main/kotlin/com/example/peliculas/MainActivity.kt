package com.example.peliculas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
